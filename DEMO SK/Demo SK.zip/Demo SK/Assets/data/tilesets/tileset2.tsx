<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="tileset2" tilewidth="64" tileheight="64" tilecount="60" columns="15">
 <image source="../../graphics/tilesets/tileset2.png" width="960" height="256"/>
</tileset>
