<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="tileset3" tilewidth="64" tileheight="64" tilecount="15" columns="5">
 <image source="../../graphics/tilesets/tileset3.png" width="320" height="192"/>
</tileset>
