<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="tileset" tilewidth="64" tileheight="64" tilecount="60" columns="15">
 <image source="../../graphics/tilesets/tileset.png" width="960" height="258"/>
</tileset>
