<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="blue_tileset_bg" tilewidth="64" tileheight="64" tilecount="24" columns="5">
 <image source="../../graphics/tilesets/blue_tileset_bg.png" width="320" height="192"/>
</tileset>
