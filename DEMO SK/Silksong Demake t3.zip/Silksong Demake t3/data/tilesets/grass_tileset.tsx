<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="grass_tileset" tilewidth="64" tileheight="64" tilecount="21" columns="7">
 <image source="../../graphics/tilesets/Grass_tileset.png" width="448" height="192"/>
</tileset>
