<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="lace_tileset_bg" tilewidth="64" tileheight="64" tilecount="36" columns="12">
 <image source="../../graphics/tilesets/Lace_tiles_bg.png" width="768" height="192"/>
</tileset>
