<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="platforms" tilewidth="64" tileheight="64" tilecount="24" columns="6">
 <image source="../../graphics/tilesets/platforms.png" width="384" height="256"/>
</tileset>
